# Hazra Bari Dual Temple – Rectify Final

Main Streamlit entry file: `jagdamba.py`

Includes Maa Durga Mandir and Baba Mahadev Mandir with shared features, deity-specific content, dynamic IST weekday colours, light/dark phase styling, and functional Aarti Thali.

Aarti Thali fix: “Select Complete Thali” updates checkbox state before the keyed checkbox widgets are instantiated, preventing StreamlitWidgetAlreadyInstantiatedError.

Theme: Monday White, Tuesday Pinkish Red, Wednesday Green, Thursday Yellow, Friday Silver, Saturday Bright Blue, Sunday Maroon/Orange. Light phase 05:30–17:30 IST; dark phase 17:30–05:30 IST. The theme is recomputed on each Streamlit script rerun.


Aarti audio mapping:
- Maa Durga Aarti: Jai Ambe Gauri (T-Series) — -rKAOaS7Q3I
- Shiva Aarti: Om Jai Shiv Omkara (T-Series) — BhwOproElxU
