HAZRA BARI DUAL TEMPLE — 143143

Main file: 143143.py

This build restores the rich Mandir navigation while retaining the newer dual-temple and strict-schedule work.

Main navigation:
Home, Darshan, Calendar, Reminders, Japa, Puja, Sankalp, Prasad, Granth, Bhajan, Map, Donation, Diya, Aarti, Search, Account, Advanced, Temple Rooms, Dashboard, V15 Center, Switch Temple, Panchang.

Dual temple:
- Maa Durga Temple
- Mahadev Shiva Temple

Strict Puja schedule (IST):
05:00–06:30 Mangal Aarti
06:30–07:00 Shringaar Aarti
07:00–11:45 Morning Chadhawa / Seva
11:45–12:15 Bhog Seva
12:15–12:30 Bhog Aarti
12:30–16:30 Japa Sadhana
16:30–18:30 Evening Chadhawa / Seva
18:30–19:00 Evening Aarti
19:00–21:00 Evening Darshan
21:00–21:15 Sayan Aarti

Wrong-time actions are blocked by the task gate and the app tells the devotee what task is currently scheduled.

Panchang:
Dedicated live Durgapur Panchang page. It uses the configured live Panchang source and does not invent astronomical values when unavailable.

Theme:
- Daily colour rolls at 04:00 AM IST.
- Light/Dark phase follows actual sunrise/sunset when live Panchang sunrise/sunset is available.
- Weekday colour schedule and Ashtami red override are retained.

Deployment:
Use 143143.py as the Streamlit entrypoint. Add PANCHANG_API_URL in Streamlit Secrets if using the configured live API path. Optional SUPABASE_URL and SUPABASE_KEY are read from Streamlit Secrets/environment for event sync.

Validation performed locally:
- Python compile check passed.
- Literal Streamlit key duplicate scan passed.
- ZIP integrity checked after packaging.
- Streamlit Cloud browser/runtime was not available for this local validation.
