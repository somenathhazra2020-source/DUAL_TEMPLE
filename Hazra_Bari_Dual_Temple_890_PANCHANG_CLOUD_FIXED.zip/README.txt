HAZRA BARI DUAL TEMPLE — 890.PY
Accurate Durgapur Panchang + Dynamic Mandir Theme

Main file: 890.py

IMPORTANT DEPLOYMENT:
- Keep 890.py and requirements.txt in the repository root.
- Streamlit Cloud must install pysweph==2.10.3.6 before starting the app.
- If the old deployment still shows every Panchang card as “Unavailable”, redeploy/reboot the app using this package and make 890.py the Main file.

Panchang engine:
- Swiss Ephemeris (pyswisseph)
- Lahiri ayanamsa for Nirayana/Vedic Sun/Moon positions
- Durgapur coordinates: 23.51583 N, 87.30801 E, altitude 100 m
- IST / Asia-Kolkata
- Tithi, Nakshatra, Yoga, Karana, Paksha
- Sunrise, Sunset, Moonrise, Moonset
- Panchang-day convention: the Panchang day begins at sunrise; therefore a pre-sunrise Moonrise is not shown as that day's Moonrise.
- Astronomical theme boundary uses the actual astronomical moonrise after local midnight.
- Theme light phase: actual sunrise to actual sunset.
- Ashtami override: bright red for Krishna Ashtami / Shukla Ashtami.
- Automatic Streamlit refresh every 60 seconds when streamlit-autorefresh is available.

Panchang reliability improvements in this version:
- Explicit Swiss Ephemeris import verification.
- Runtime exception protection around Panchang calculation.
- No silent “Unavailable” cards when the dependency is missing; the app shows the actual deployment diagnostic.
- No hard-coded daily Panchang values.

Existing dual-temple features are retained. This package changes the Panchang reliability/diagnostic layer and renames the main Python file to 890.py.

Validation reference:
Drik Panchang, Durgapur, West Bengal, 8 October 2026.
Reference values include Sunrise 05:35 AM, Sunset 05:21 PM, Moonset 03:47 PM, Krishna Trayodashi, Purva Phalguni and Shukla Yoga. Swiss Ephemeris can differ by a small amount for lunar event conventions; the code does not hard-code these reference values.


DEPLOYMENT NOTE
The Swiss Ephemeris dependency uses pysweph 2.10.3.6, the maintained continuation of pyswisseph. It keeps the same Python import name: swisseph. This version provides Linux wheels for modern Python versions including CPython 3.13, reducing the risk of ModuleNotFoundError on Streamlit Community Cloud.
