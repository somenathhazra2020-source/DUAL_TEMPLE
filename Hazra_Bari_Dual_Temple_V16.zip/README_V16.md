# HAZRA BARI DUAL TEMPLE V16

This build upgrades the existing Hazra Bari Virtual Durga Mandir into a dual-temple system:

- Maa Durga mode
- Mahadev mode
- Supabase/PostgreSQL-backed permanent state snapshot with SQLite local cache/fallback
- Real-time activity dashboard
- Devotional reminder controls
- Temple-aware devotional assistant
- Durgapur Panchang API hook
- Guided Aarti ritual flow
- Admin control center extensions
- PWA/mobile-ready architecture
- Existing Darshan, Seva, Bhog, Japa, Sankalp, Khetri, Navratri, wallet, history and admin features preserved

## Supabase setup

1. Create a Supabase project.
2. Open SQL Editor and run `supabase_schema.sql`.
3. In Streamlit Secrets/environment configure:

```toml
SUPABASE_URL = "https://YOUR_PROJECT.supabase.co"
SUPABASE_SERVICE_ROLE_KEY = "YOUR_SERVICE_ROLE_KEY"
ADMIN_EMAILS = "admin@example.com"
```

Do **not** expose the service-role key in frontend code or GitHub.

## Panchang

Configure a trusted Panchang API endpoint as:

```toml
PANCHANG_API_URL = "https://YOUR-PANCHANG-ENDPOINT"
```

The endpoint should accept `city`, `state`, and `country` query parameters and return JSON fields:
`tithi`, `nakshatra`, `sunrise`, `sunset`, `moonrise`, `moonset`, `paksha`, `upcoming_festival`.

If it is not configured, the app deliberately does not invent astronomical values.

## Deploy

Use `app.py` as the Streamlit entrypoint. Rename `app%2819%29.py` to `app.py` when uploading.

The PWA metadata is provided separately for the later mobile/PWA wrapper stage. Streamlit should be stabilized first.
